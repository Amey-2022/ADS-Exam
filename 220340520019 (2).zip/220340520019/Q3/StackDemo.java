import java.util.*;

class Stack{
	
	int arr[];
	int top1,top2,n;
	
	Stack(int n){
	arr=new int[n];
	top1=(n/2)+1;
	top2=n/2;
	}

	public void push1(int num){
		if(top1>0){
			top1--;
			arr[top1]=num;
		}
		else{
			System.out.println("Stack Overflow");
		}
	}
	
	public void push2(int num){
		if(top2<arr.length-1){
			top++;
			arr[top2]=num;
		}
		else{
			System.out.println("Stack Overflow");
			return;
		}
	}
	
	public int pop1(){
		if(top1<=n/2){
			int z=arr[top1];
			top++;
			return z;
		}
		else{
			System.out.println("Stack Underflow");
			return;
		}
		return;
	}
	public int pop1(){
		if(top2>=n/2+1){
			int z=arr[top2];
			top--;
			return z;
		}
		else{
			System.out.println("Stack Underflow");
			return;
		}
		return;
	}
	
}
class StackDemo{
	public static void main(String[] args){
		Stack s=new Stack();
		s.push1(5);
		s.push2(10);
		s.push2(15);
		s.push1(11);
		s.push2(7);
		s.push2(40);
		
		s.pop1();
		s.pop2();
		
	}
}