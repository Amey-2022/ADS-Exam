import java.util.*;

class SinglyLinkedList{

		public class Node{
			int data;
			Node next;
		

		Node(){
			data=0;
			next=null;
		}
		
		Node(int val){
			data=val;
			next=null;
		}
	}
	
	Node head,tail;
	
	SinglyLinkedList(){
		head=null;
		tail=null;
	}
	
	public boolean isEmpty(){
		return head==null;
	}
	
	
	public void addNode(int val){
		Node newNode=new Node(val);
		if(isEmpty()){
			head=newNode;
		}
		else{
			Node trav=head;
			while(trav.next!=null){
				trav=trav.next;
			}
			trav.next=newNode;
		}	
	}
	
	public void deleteFirst(){
		if(isEmpty()){
			System.out.println("List is Empty");
		}
		else{
			head=head.next;
		}
	}
	
	public void displayForward(){
		
		if(isEmpty()){
			System.out.println("List is Empty");
		}
		else{
			Node trav=head;
			while(trav!=null){
				System.out.print(trav.data+"->");
				trav=trav.next;
			}
			System.out.println("\n");
		}
	}
	
	
	public void displayReverse(){
		deleteFirst();
		deleteFirst();
		System.out.println("Reverse list:");
		if(isEmpty()){
			System.out.println("List is Empty");
		}
		
		else{
			Node oldhead=head;
			head=null;
			Node temp=null;
			while(oldhead!=null){
				temp=oldhead;
				oldhead=oldhead.next;
				temp.next=head;
				head=temp;
			}
		}
		displayForward();
		System.out.println("\n");
	}


}

class SinglyLinkedListDemo{
					public static void main(String[] args){
						
						//int choice,val
					SinglyLinkedList s=new SinglyLinkedList();	
					
					System.out.println("Test case 1:");
					s.addNode(2);
					s.addNode(4);
					s.addNode(3);
					s.addNode(4);
					s.addNode(2);
					s.addNode(5);
					s.displayForward();
					s.displayReverse();
					
					
					
					System.out.println("Test case 2:");
					s.addNode(1);
					s.addNode(5);
					s.addNode(1);
					s.addNode(2);
					s.addNode(3);
					s.addNode(4);
					s.addNode(5);
					s.displayForward();
					s.displayReverse();
					
					
					
					
					
					
					//can be done by switch case also
					
					/*do{
						System.out.print("1.addnode   2.Deletenode  3.Display   4.Reverse");
						System.out.println("Enter choice");
						
						
						switch(choice){
							
							
							
							
						}
						
					}while(choice!=0)*/
					
					}
	
	
	
}